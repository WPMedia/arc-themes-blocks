import axios from "axios";
import { ARC_ACCESS_TOKEN, CONTENT_BASE, RESIZER_TOKEN_VERSION } from "fusion:environment";
import signImagesInANSObject from "@wpmedia/arc-themes-components/src/utils/sign-images-in-ans-object";
import handleFetchError from "@wpmedia/arc-themes-components/src/utils/handle-fetch-error";
import { fetch as resizerFetch } from "@wpmedia/signing-service-content-source-block";

const params = [
	{
		displayName: "Document ID",
		name: "id",
		type: "text",
	},
	{
		displayName: "Schema Name",
		name: "schemaName",
		type: "text",
	},
	{
		default: "2",
		displayName: "Themes Version",
		name: "themes",
		type: "text",
	},
];

const fetch = ({ id, schemaName, "arc-site": website }, { cachedCall, arcSite }) => {
	if (!id || !schemaName) {
		return "";
	}

	const siteValue = website || arcSite;
	if (!siteValue) {
		return "";
	}

	const urlSearch = new URLSearchParams({
		id: id.trim(),
		schema_name: schemaName.trim(),
		website: siteValue,
	});

	return axios({
		url: `${CONTENT_BASE}/content/v5/search/schemas/by-id/?${urlSearch.toString()}`,
		headers: {
			"content-type": "application/json",
			Authorization: `Bearer ${ARC_ACCESS_TOKEN}`,
		},
		method: "GET",
	})
		.then(signImagesInANSObject(cachedCall, resizerFetch, RESIZER_TOKEN_VERSION))
		.then(({ data }) => {
			if (!data) {
				const error = new Error("Document not found");
				error.statusCode = 404;
				throw error;
			}
			return data;
		})
		.catch(handleFetchError);
};

export default {
	fetch,
	params,
	ttl: 300,
};
